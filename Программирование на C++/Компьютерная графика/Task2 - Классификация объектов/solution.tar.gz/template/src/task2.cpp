#include <string>
#include <vector>
#include <fstream>
#include <cassert>
#include <iostream>
#include <cmath>

#include "classifier.h"
#include "EasyBMP.h"
#include "linear.h"
#include "argvparser.h"
#include "matrix.h"

using std::string;
using std::vector;
using std::ifstream;
using std::ofstream;
using std::pair;
using std::make_pair;
using std::cout;
using std::cerr;
using std::endl;

using CommandLineProcessing::ArgvParser;

typedef vector<pair<BMP*, int> > TDataSet;
typedef vector<pair<string, int> > TFileList;
typedef vector<pair<vector<float>, int> > TFeatures;

const int seg_num  = 8; // Number of segments
const int cell_num = 8; // Number of cells
const float M_PI = 3.141592653589793238462643383279502884L; // Pi number

// Load list of files and its labels from 'data_file' and
// stores it in 'file_list'
void LoadFileList(const string& data_file, TFileList* file_list) {
    ifstream stream(data_file.c_str());

    string filename;
    int label;
    
    int char_idx = data_file.size() - 1;
    for (; char_idx >= 0; --char_idx)
        if (data_file[char_idx] == '/' || data_file[char_idx] == '\\')
            break;
    string data_path = data_file.substr(0,char_idx+1);
    
    while(!stream.eof() && !stream.fail()) {
        stream >> filename >> label;
        if (filename.size())
            file_list->push_back(make_pair(data_path + filename, label));
    }

    stream.close();
}

// Load images by list of files 'file_list' and store them in 'data_set'
void LoadImages(const TFileList& file_list, TDataSet* data_set) {
    for (size_t img_idx = 0; img_idx < file_list.size(); ++img_idx) {
            // Create image
        BMP* image = new BMP();
            // Read image from file
        image->ReadFromFile(file_list[img_idx].first.c_str());
            // Add image and it's label to dataset
        data_set->push_back(make_pair(image, file_list[img_idx].second));
    }
}

// Save result of prediction to file
void SavePredictions(const TFileList& file_list,
                     const TLabels& labels, 
                     const string& prediction_file) {
        // Check that list of files and list of labels has equal size 
    assert(file_list.size() == labels.size());
        // Open 'prediction_file' for writing
    ofstream stream(prediction_file.c_str());

        // Write file names and labels to stream
    for (size_t image_idx = 0; image_idx < file_list.size(); ++image_idx)
        stream << file_list[image_idx].first << " " << labels[image_idx] << endl;
    stream.close();
}

// Exatract features from dataset.
void ExtractFeatures(const TDataSet& data_set, TFeatures* features) {
    for (size_t image_idx = 0; image_idx < data_set.size(); ++image_idx) {

        BMP* image = data_set[image_idx].first;
        int row = image->TellWidth();
        int col = image->TellHeight();
        RGBApixel p;

        vector<float> main_features;

        // Grayscale
        Matrix<float> gray_scale(row,col);
        for (int i=0; i<row; i++) {
            for (int j=0; j<col; j++) {
                p = image->GetPixel(i,j);
                gray_scale(i,j) = 0.299f*p.Red + 0.587f*p.Green + 0.114f*p.Blue;
            }
        }

        // Mirror reflection of bounds
        Matrix<float> tmp = gray_scale.extra_borders(1,1);

        // Horizontal Sobel & Verical Sobel
        Matrix<float> sobel_hor(row,col);
        Matrix<float> sobel_ver(row,col);
        for(uint i=1 ; i<tmp.n_rows-1 ; i++) {
            for(uint j=1; j<tmp.n_cols-1; j++) {
                sobel_hor(i-1,j-1) = tmp(i,j+1) - tmp(i,j-1);
                sobel_ver(i-1,j-1) = tmp(i-1,j) - tmp(i+1,j);
            }
        }

        // Gradient Modulus & Gradient Direction
        Matrix<float> grad_mod(row,col);
        Matrix<float> grad_dir(row,col);
        for(int i=0 ; i<row ; i++) {
            for(int j=0 ; j<col ; j++) {
                grad_mod(i,j) = sqrt(sobel_hor(i,j)*sobel_hor(i,j) + sobel_ver(i,j)*sobel_ver(i,j));
                grad_dir(i,j) = atan2(sobel_ver(i,j), sobel_hor(i,j));
            }
        }


        // Descriptor
        float* arr = new float[seg_num];
        int pos = 0;
        for (int i=0; i<cell_num; i++) {
            for (int j=0; j<cell_num; j++) {
                int row_from = (i*row)/cell_num;
                int row_to   = ((i+1)*row)/cell_num;
                int col_from = (j*col)/cell_num;
                int col_to   = ((j+1)*col)/cell_num;

                // Histogram of Oriented Gradients
                for (int x=row_from; x<row_to; x++) {
                    for (int y=col_from; y<col_to; y++) {
                        float tmp1 = -0.5 + seg_num * ((grad_dir(x,y)+M_PI)/(2*M_PI));
                        pos = static_cast<int>(tmp1);
                        if (pos<0) {pos=0;} else if (pos>seg_num-1) {pos=seg_num-1;}
                        arr[pos] += grad_mod(x,y);
                    }
                }

                // Normalization of HOG
                float norm=0.f;
                for (int k=0; k<seg_num; k++) { norm += arr[k]*arr[k]; }
                norm = sqrt(norm);
                if (norm > 0.f) {
                    for (int k=0; k<seg_num; k++) { arr[k] /= norm; }
                }

                // Cell Features Pushing
                for (int k=0; k<seg_num; k++) {main_features.push_back(arr[k]);}

                
                // LOCAL BINARY PATTERNS
                float *lbp = new float[256]; for (int k=0; k<256; k++) {lbp[k] = 0;}
                for (int x=row_from+1; x<row_to-1; x++) {
                    for (int y=col_from+1; y<col_to-1; y++) {

                    float neighbor[3][3];
                    int tmp1 = 0;

                    for (int m=0; m<3; m++) {
                        for (int n=0; n<3; n++)
                        {
                            p = image->GetPixel( x-1+m, y-1+n );
                            neighbor[m][n] = 0.299f*p.Red + 0.587f*p.Green + 0.114f*p.Blue;
                            
                            if (m!=1 || n!=1){
                                int temp=0;
                                if (neighbor[1][1] > neighbor[m][n]) {temp=0;} else {temp=1;}
                                tmp1 = tmp1*2 + temp;
                            }
                        } 	
                    }
                    lbp[tmp1] += 1;  
                    }
                }

                // Normalizing LBP Histogram
                norm=0.f;
                for (int k=0; k<256; k++) { norm += lbp[k]*lbp[k]; }
                norm = sqrt(norm);
                if (norm > 0.f) {
                    for (int k=0; k<256; k++) { lbp[k] /= norm; }
                }

                // Pushing LBP Histogram
                for (int k = 0; k < 256; k++) main_features.push_back(lbp[k]);  
                 
            }
        }


        // COLOR FEATURES
        for (int i=0; i<8; i++) {
            for (int j=0; j<8; j++) {
                int row_from = (i*row)/8;
                int row_to   = ((i+1)*row)/8;
                int col_from = (j*col)/8;
                int col_to   = ((j+1)*col)/8;

                int R=0, G=0, B=0;

                for (int x=row_from; x<row_to; x++) {
                    for (int y=col_from; y<col_to; y++) {
                        
                        p = image->GetPixel(x,y);
                        R += p.Red; G += p.Green; B += p.Blue;
                    }
                }

                main_features.push_back(R/((row_to-row_from)*(col_to-col_from)*255));
                main_features.push_back(G/((row_to-row_from)*(col_to-col_from)*255));
                main_features.push_back(B/((row_to-row_from)*(col_to-col_from)*255));
            }
        }

        features->push_back(make_pair(main_features, data_set[image_idx].second));
    }
}



// Clear dataset structure
void ClearDataset(TDataSet* data_set) {
        // Delete all images from dataset
    for (size_t image_idx = 0; image_idx < data_set->size(); ++image_idx)
        delete (*data_set)[image_idx].first;
        // Clear dataset
    data_set->clear();
}

// Train SVM classifier using data from 'data_file' and save trained model
// to 'model_file'
void TrainClassifier(const string& data_file, const string& model_file) {
        // List of image file names and its labels
    TFileList file_list;
        // Structure of images and its labels
    TDataSet data_set;
        // Structure of features of images and its labels
    TFeatures features;
        // Model which would be trained
    TModel model;
        // Parameters of classifier
    TClassifierParams params;
    
        // Load list of image file names and its labels
    LoadFileList(data_file, &file_list);
        // Load images
    LoadImages(file_list, &data_set);
        // Extract features from images
    ExtractFeatures(data_set, &features);

        // PLACE YOUR CODE HERE
        // You can change parameters of classifier here
    params.C = 0.01;
    TClassifier classifier(params);
        // Train classifier
    classifier.Train(features, &model);
        // Save model to file
    model.Save(model_file);
        // Clear dataset structure
    ClearDataset(&data_set);
}

// Predict data from 'data_file' using model from 'model_file' and
// save predictions to 'prediction_file'
void PredictData(const string& data_file,
                 const string& model_file,
                 const string& prediction_file) {
        // List of image file names and its labels
    TFileList file_list;
        // Structure of images and its labels
    TDataSet data_set;
        // Structure of features of images and its labels
    TFeatures features;
        // List of image labels
    TLabels labels;

        // Load list of image file names and its labels
    LoadFileList(data_file, &file_list);
        // Load images
    LoadImages(file_list, &data_set);
        // Extract features from images
    ExtractFeatures(data_set, &features);

        // Classifier 
    TClassifier classifier = TClassifier(TClassifierParams());
        // Trained model
    TModel model;
        // Load model from file
    model.Load(model_file);
        // Predict images by its features using 'model' and store predictions
        // to 'labels'
    classifier.Predict(features, model, &labels);

        // Save predictions
    SavePredictions(file_list, labels, prediction_file);
        // Clear dataset structure
    ClearDataset(&data_set);
}

int main(int argc, char** argv) {
    // Command line options parser
    ArgvParser cmd;
        // Description of program
    cmd.setIntroductoryDescription("Machine graphics course, task 2. CMC MSU, 2018.");
        // Add help option
    cmd.setHelpOption("h", "help", "Print this help message");
        // Add other options
    cmd.defineOption("data_set", "File with dataset",
        ArgvParser::OptionRequiresValue | ArgvParser::OptionRequired);
    cmd.defineOption("model", "Path to file to save or load model",
        ArgvParser::OptionRequiresValue | ArgvParser::OptionRequired);
    cmd.defineOption("predicted_labels", "Path to file to save prediction results",
        ArgvParser::OptionRequiresValue);
    cmd.defineOption("train", "Train classifier");
    cmd.defineOption("predict", "Predict dataset");
        
        // Add options aliases
    cmd.defineOptionAlternative("data_set", "d");
    cmd.defineOptionAlternative("model", "m");
    cmd.defineOptionAlternative("predicted_labels", "l");
    cmd.defineOptionAlternative("train", "t");
    cmd.defineOptionAlternative("predict", "p");

        // Parse options
    int result = cmd.parse(argc, argv);

        // Check for errors or help option
    if (result) {
        cout << cmd.parseErrorDescription(result) << endl;
        return result;
    }

        // Get values 
    string data_file = cmd.optionValue("data_set");
    string model_file = cmd.optionValue("model");
    bool train = cmd.foundOption("train");
    bool predict = cmd.foundOption("predict");

        // If we need to train classifier
    if (train)
        TrainClassifier(data_file, model_file);
        // If we need to predict data
    if (predict) {
            // You must declare file to save images
        if (!cmd.foundOption("predicted_labels")) {
            cerr << "Error! Option --predicted_labels not found!" << endl;
            return 1;
        }
            // File to save predictions
        string prediction_file = cmd.optionValue("predicted_labels");
            // Predict data
        PredictData(data_file, model_file, prediction_file);
    }
}